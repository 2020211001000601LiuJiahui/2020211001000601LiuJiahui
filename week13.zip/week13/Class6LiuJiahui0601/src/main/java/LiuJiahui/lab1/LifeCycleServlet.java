package LiuJiahui.lab1;
import javax.servlet.*;
import java.io.InvalidObjectException; 
public class LifeCycleServlet extends HttpServlet{
	public void init(ServletConflg conflg)throws ServletExceptinon{
		System.out.println("init");
	}
	public void doGet(HttpServletRequset requset,HttpServletResponse response)
	throws ServletException,InvalidObjectException{
		System.out.println("service");
		//System.out.println(getServletConflg().geetlnitParameter("email"));
	}
	public void destroy() {
		System.out.println("destroy");
	}
}//end of class
