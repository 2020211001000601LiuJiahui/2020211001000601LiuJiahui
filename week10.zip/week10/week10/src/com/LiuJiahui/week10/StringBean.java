package com.LiuJiahui.week10;

public class StringBean {
    //property-variable
    private String message;

    //get
    public String getMessage() {
        return message;
    }

    //set
    public void setMessage(String message) {
        this.message = message;
    }
}
